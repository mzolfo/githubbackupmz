<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Forestorwhatever" tilewidth="16" tileheight="16" tilecount="136" columns="17">
 <image source="ForestSheet.png" width="272" height="128"/>
 <tile id="7">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
</tileset>
